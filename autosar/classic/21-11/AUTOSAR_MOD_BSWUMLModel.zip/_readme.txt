Document Title:                 Basic Software UML Model
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 52
Document Status:                published
Part of AUTOSAR Standard:       Classic Platform
Part of Standard Release:       R21-11
Date:                           2021-11-25
