/** @file     Rte_Environment_Type.h
  * 
  * @brief    Application types header file
  * 
  * @note     AUTOMATICALLY GENERATED FILE! DO NOT EDIT!
  * 
  */

#ifndef RTE_Environment_TYPE_H
#define RTE_Environment_TYPE_H

#include "Rte_Type.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* BEGIN: SWC specific types */
/* END: SWC specific types */

/* BEGIN: SWC specific definitions */
/* END: SWC specific definitions */

#ifdef __cplusplus
} /* extern C */
#endif /* __cplusplus */

#endif /* !RTE_Environment_TYPE_H */
