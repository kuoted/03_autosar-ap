Document Title:                 Meta Model
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 059
Document Status:                published
Part of AUTOSAR Standard:       Foundation
Part of Standard Release:       R23-11
Date:                           2023-11-23
